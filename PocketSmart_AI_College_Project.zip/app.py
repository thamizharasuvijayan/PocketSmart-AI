from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = "pocketsmart-college-project-key"
DB = "pocketsmart.db"

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.execute("""CREATE TABLE IF NOT EXISTS expenses(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category TEXT NOT NULL,
        amount REAL NOT NULL,
        note TEXT,
        date TEXT NOT NULL
    )""")
    con.commit()
    con.close()

def get_data():
    con=db()
    rows=con.execute("SELECT * FROM expenses ORDER BY id DESC").fetchall()
    con.close()
    return rows

def recommendation(total, income, by_cat):
    if income <= 0:
        return "Enter your monthly income to get personalized recommendations."
    ratio = total / income * 100
    if ratio >= 90:
        return "Your spending is very high. Reduce non-essential expenses and protect your savings."
    if ratio >= 75:
        return "You are using most of your income. Try setting a weekly spending limit."
    if by_cat:
        cat, amt = max(by_cat.items(), key=lambda x:x[1])
        return f"Your highest spending category is {cat} (₹{amt:.0f}). Consider reducing it to improve savings."
    return "Good start! Add your expenses to receive a personalized recommendation."

@app.route("/", methods=["GET","POST"])
def index():
    if request.method=="POST":
        category=request.form.get("category","Other")
        amount=float(request.form.get("amount",0))
        note=request.form.get("note","")
        date=request.form.get("date") or datetime.now().strftime("%Y-%m-%d")
        con=db()
        con.execute("INSERT INTO expenses(category,amount,note,date) VALUES(?,?,?,?)",
                    (category,amount,note,date))
        con.commit(); con.close()
        return redirect(url_for("index"))

    rows=get_data()
    income=float(session.get("income", 0))
    total=sum(r["amount"] for r in rows)
    by_cat={}
    for r in rows:
        by_cat[r["category"]]=by_cat.get(r["category"],0)+r["amount"]
    balance=income-total
    rec=recommendation(total,income,by_cat)
    return render_template("index.html", rows=rows, income=income,total=total,
                           balance=balance, by_cat=by_cat, recommendation=rec)

@app.route("/income", methods=["POST"])
def income():
    session["income"]=float(request.form.get("income",0))
    return redirect(url_for("index"))

@app.route("/delete/<int:eid>")
def delete(eid):
    con=db(); con.execute("DELETE FROM expenses WHERE id=?", (eid,))
    con.commit(); con.close()
    return redirect(url_for("index"))

@app.route("/clear")
def clear():
    con=db(); con.execute("DELETE FROM expenses"); con.commit(); con.close()
    return redirect(url_for("index"))

init_db()
app.run(debug=True)
