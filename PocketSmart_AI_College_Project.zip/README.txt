# PocketSmart AI – Smart Budget & Recommendation Assistant

## What this project does
A simple college-project web application for recording income and expenses, viewing spending categories, calculating remaining balance, and generating a rule-based smart recommendation.

## Technology
- Python
- Flask
- SQLite
- HTML/CSS/JavaScript
- Chart.js

## Run
1. Install Python 3.
2. Open terminal in this folder.
3. Run: `pip install -r requirements.txt`
4. Run: `python app.py`
5. Open the local address shown by Flask (normally http://127.0.0.1:5000).

The SQLite database `pocketsmart.db` is created automatically.
